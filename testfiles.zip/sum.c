/*Sum integers 0 thru n*/

int x; int count; int ans;

void main(void)
{
   x = 0;
   ans = 0;
   x = 5; 
   
   while (count <= x) 
   {
      ans = ans + count;
      count = count + 1;
   }
   


}    /*of program*/

