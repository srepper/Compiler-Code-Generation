int f(int x, int y, int z) 
{
  int a;
  { int b;
	{int c;
  int d;
  }
  x = 2 + 3;
  }
  return a;
}

void main(void)
{
}