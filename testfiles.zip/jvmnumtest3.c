void f(void) {/* JVM # 0 and 1 */
  int x; int y;
}

void main(void) {}
